<?php

use Illuminate\Support\Facades\Route;

Route::get('/plugins/clock/index', function () {
    return "Custom Route Working!";
});